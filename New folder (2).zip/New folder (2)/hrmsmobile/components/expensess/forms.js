import React, { Component } from 'react';
import {Text, View, StyleSheet, TextInput, Button} from 'react-native';

class Forms extends Component {

    state = {
        editedExpenses: null
     }

    inputChanged = (name, value) => {
         console.log('input change', name, value);
         expenses = this.props.navigation.getParam('expenses', '');
         expenses[name] = value;
         this.setState({ editedExpenses: expenses });
     }
     save = () => {
        console.log('save click');
        token = this.props.navigation.getParam('token', '');
        fetch('http://192.168.24.107:8000/api/expensess/', {
         method: 'POST',
         headers: {
         'Content-Type': 'application/json',
         'Authorization': `Token ${token}`
         },
         body: JSON.stringify(this.state.editedExpenses)
         }).then( resp => resp.json())
         .then( res => this.props.navigation.navigate('Details', { 
         expenses: this.state.editedExpenses
         }) 
         )
         .catch( error => console.log(error))
         } 
     
     update = () => {
         console.log('update click');
         token = this.props.navigation.getParam('token', '');
         expenses = this.props.navigation.getParam('expenses', '');
         fetch(`http://192.168.24.107:8000/api/employees/${expenses.id}/`, {
         method: 'PUT',
         headers: {
         'Content-Type': 'application/json',
         'Authorization':  `Token ${token}`
         },
         body: JSON.stringify(
         this.state.editedExpenses
         )
         }).then( resp => resp.json())
         .then( res => this.props.navigation.navigate('Details', { 
         expenses: this.state.editedExpenses
         }))
         .catch( error => console.log(error))
     }


 render() {

    expenses = this.props.navigation.getParam('expenses', '');
    view_type = this.props.navigation.getParam('view_type', '');

 return (
     <View style={styles.container}>
         <View style={{ marginBottom:20, height: 100, 
            alignItems:"center", justifyContent: "center"}}>
             <Text style={{ fontSize: 20, fontWeight: 'bold', 
              marginBottom: 20}}> Expenses Form </Text>
         </View>
         <TextInput 
         style={styles.inputText} 
         value={expenses.name}
         onChangeText={value => this.inputChanged('name', value)}
         />
         <TextInput 
         style={styles.inputText} 
         value={expenses.date}
         onChangeText={value => this.inputChanged('date', value)}
         />
         
         <View style={{ width: '80%'}}>
         {
        view_type ? <Button onPress={this.save} title="Save" />
                  : <Button onPress={this.update} title="Update" />
        }

    </View>
     </View>
     );
     }
}
Form.navigationOptions = {
     title: "Form Screen",
     headerStyle: {
     backgroundColor: 'green'
     },
     headerTintColor: '#fff',
}
const styles = StyleSheet.create({
     container: {
     flex: 1,
     backgroundColor: "#fff",
     alignItems: "center",
 },
     inputText: {
     height: 50,
     padding: 10,
     height: 45,
     width: "80%",
     borderRadius: 10,
     marginBottom: 20,
     borderColor: 'blue', 
     borderWidth: 1
 },

});
export default Forms;