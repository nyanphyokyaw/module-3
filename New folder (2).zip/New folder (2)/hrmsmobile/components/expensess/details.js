import React ,{ Component } from 'react';
import {Text, View, StyleSheet , Button} from 'react-native';

class Details extends Component {

    token = null;

    deleteClicked = () => {
     console.log('delete click');
     token = this.props.navigation.getParam('token', '');
     expenses = this.props.navigation.getParam('expenses', '');
     fetch(`http://192.168.24.107:8000/api/expensess/${expenses.id}/`, {
     method: 'DELETE',
     headers: {
     'Content-Type': 'application/json',
     'Authorization': `Token ${token}`
     }
     })
     .then( res => this.props.navigation.navigate('Lists'))
     .catch( error => console.log(error))
     }

     render() {
        expenses = this.props.navigation.getParam('expenses', '');
         return (
            <View style={styles.container}>
                 <View style={{ marginBottom:20, height: 100, 
                 alignItems:"center", justifyContent: "center"}}>
                 <Text style={{fontSize:20, fontWeight:'bold'}}> Expenses Details </Text>
         </View>
            <View style={{ marginLeft:20, alignItems: 'flex-start' }}>
                 <Text> Name: { expenses.name } </Text>
                     <Text> Phone: { expenses.date } </Text>
         </View>
            <View style={{ marginTop:50, alignItems:"center"}}>
            <View style={{ width: '80%'}}>
                 <Button title="Update" 
             onPress={() => 
             this.props.navigation.navigate('Form',{expenses: expenses, view_type: false,token: token })}
             /> 
             <Text />
                <Button title="Delete" 
                 onPress={this.deleteClicked} />
             <Text />
            <Button title="Home" onPress={() => 
            this.props.navigation.navigate('Lists')} />
         </View>
         </View>
     </View>
 );
 }
}
Detail.navigationOptions = {
     title: "Detail Screen",
     headerStyle: {
     backgroundColor: 'orange'
     },
     headerTintColor: '#fff'
}
const styles = StyleSheet.create({
     container: {
     flex: 1,
     backgroundColor: "#fff",
     }
});
export default Details;
